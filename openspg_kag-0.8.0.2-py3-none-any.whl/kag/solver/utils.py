def init_prompt_with_fallback(prompt_name, biz_scene):
    from kag.builder.prompt.utils import init_prompt_with_fallback as func

    return func(prompt_name, biz_scene)
